import React from 'react'

const BookingComponents = () => {
    return (
        <div>
            
        </div>
    )
}

export default BookingComponents
