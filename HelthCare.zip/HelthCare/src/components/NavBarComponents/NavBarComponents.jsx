import React, { Fragment } from 'react'

const NavBarComponents = () => {
    return (
        <Fragment>
            <div className>
                
            </div>
            
        </Fragment>
    )
}

export default NavBarComponents
